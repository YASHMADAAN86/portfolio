.navbar-brand{
  color:white;
}